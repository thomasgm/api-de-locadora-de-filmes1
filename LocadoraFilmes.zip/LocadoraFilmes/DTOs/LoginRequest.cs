namespace LocadoraFilmes.DTOs;

public record LoginRequest(string Email, string Senha);
