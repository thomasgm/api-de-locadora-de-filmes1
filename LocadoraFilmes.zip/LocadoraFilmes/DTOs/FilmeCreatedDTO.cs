using System.ComponentModel.DataAnnotations;

namespace LocadoraFilmes.DTOs;

public record FilmeCreateDto(
    [property: Required(ErrorMessage = "O título é obrigatório.")]
    [property: StringLength(255, ErrorMessage = "O título deve ter no máximo 255 caracteres.")]
    string Titulo,

    [property: Required(ErrorMessage = "O diretor é obrigatório.")]
    [property: StringLength(255, ErrorMessage = "O diretor deve ter no máximo 255 caracteres.")]
    string Diretor,

    string Sinopse,

    [property: Required(ErrorMessage = "O ano é obrigatório.")]
    [property: Range(1888, 2100, ErrorMessage = "O ano deve ser entre 1888 e 2100.")]
    int Ano,

    [property: Required(ErrorMessage = "Pelo menos um gênero é obrigatório.")]
    List<string> Generos,
    
    [property: Required(ErrorMessage = "A quantidade disponível é obrigatória.")]
    [property: Range(0, int.MaxValue, ErrorMessage = "A quantidade disponível deve ser um número inteiro não negativo.")]
    int QuantidadeDisponivel
);
