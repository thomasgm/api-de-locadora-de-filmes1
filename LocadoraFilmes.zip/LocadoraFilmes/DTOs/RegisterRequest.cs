namespace LocadoraFilmes.DTOs;

public record RegisterRequest(string Nome, string Email, string Senha);
