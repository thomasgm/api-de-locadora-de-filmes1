using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LocadoraFilmes.Data;
using LocadoraFilmes.Models;
using LocadoraFilmes.DTOs;

namespace LocadoraFilmes.Controllers;

[ApiController]
[Route("api/[controller]")]
// Esta Controller é pública (não possui [Authorize])
public class FilmesController : ControllerBase
{
    private readonly AppDbContext _context;

    public FilmesController(AppDbContext context)
    {
        _context = context;
    }

    // GET: api/filmes
    [HttpGet]
    public async Task<ActionResult<IEnumerable<FilmeResponseDto>>> GetFilmes([FromQuery] string? titulo, [FromQuery] string? genero)
    {
        var query = _context.Filmes.Include(f => f.Generos).AsQueryable();

        if (!string.IsNullOrEmpty(titulo))
            query = query.Where(f => f.Titulo.ToLower().Contains(titulo.ToLower()));

        if (!string.IsNullOrEmpty(genero))
            query = query.Where(f => f.Generos.Any(g => g.Nome.ToLower().Contains(genero.ToLower())));

        var filmes = await query.ToListAsync();

        // Mapeia a lista de modelos para uma lista de DTOs
        return filmes.Select(f => new FilmeResponseDto(
            f.Id,
            f.Titulo,
            f.Diretor,
            f.Ano,
            f.Generos.Select(g => new GeneroDTO(g.Id, g.Nome)),
            f.QuantidadeDisponivel,
            f.AdicionadoEm
        )).ToList();
    }

    // GET: api/filmes/5
    [HttpGet("{id}")]
    public async Task<ActionResult<FilmeResponseDto>> GetFilme(int id)
    {
        var f = await _context.Filmes.Include(f => f.Generos).FirstOrDefaultAsync(f => f.Id == id);
        if (f == null) return NotFound(new { message = "Filme não encontrado." });

        return new FilmeResponseDto(
            f.Id,
            f.Titulo,
            f.Diretor,
            f.Ano,
            f.Generos.Select(g => new GeneroDTO(g.Id, g.Nome)),
            f.QuantidadeDisponivel,
            f.AdicionadoEm
        );
    }

    // POST: api/filmes
    [HttpPost]
    public async Task<ActionResult<FilmeResponseDto>> PostFilme(Filme filme)
    {
        _context.Filmes.Add(filme);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetFilme), new { id = filme.Id }, new FilmeResponseDto(
            filme.Id,
            filme.Titulo,
            filme.Diretor,
            filme.Ano,
            filme.Generos.Select(g => new GeneroDTO(g.Id, g.Nome)),
            filme.QuantidadeDisponivel,
            filme.AdicionadoEm
        ));
    }

    // PUT: api/filmes/5
    [HttpPut("{id}")]
    public async Task<IActionResult> PutFilme(int id, Filme filme)
    {
        if (id != filme.Id) return BadRequest();
        _context.Entry(filme).State = EntityState.Modified;
        await _context.SaveChangesAsync();
        return NoContent();
    }

    // DELETE: api/filmes/5
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteFilme(int id)
    {
        var filme = await _context.Filmes.FindAsync(id);
        if (filme == null) return NotFound();
        _context.Filmes.Remove(filme);
        await _context.SaveChangesAsync();
        return NoContent();
    }
}
