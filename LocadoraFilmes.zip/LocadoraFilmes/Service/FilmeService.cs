using LocadoraFilmes.Data;
using LocadoraFilmes.DTOs;
using LocadoraFilmes.Models;
using Microsoft.EntityFrameworkCore;

namespace LocadoraFilmes.Services;

public class FilmeService : IFilmeService
{
    private readonly AppDbContext _context;

    public FilmeService(AppDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<FilmeResponseDto>> GetAllAsync(int page, int pageSize)
    {
        return await _context.Filmes
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(p => ToResponseDto(p))
            .ToListAsync();
    }

    public async Task<FilmeResponseDto?> GetByIdAsync(int id)
    {
        var filme = await _context.Filmes.FindAsync(id);
        return filme is null ? null : ToResponseDto(filme);
    }

    public async Task<FilmeResponseDto> CreateAsync(FilmeCreateDto dto)
    {
        var filme = new Filme
        {
            Titulo = dto.Titulo,
            Diretor = dto.Diretor,
            Ano = dto.Ano,
            QuantidadeDisponivel = dto.QuantidadeDisponivel
        };

        // Lógica para os Gêneros
        foreach (var nomeGenero in dto.Generos)
        {
            // 1. Tenta buscar o gênero já existente no banco pelo nome
            var generoExistente = await _context.Generos
                .FirstOrDefaultAsync(g => g.Nome.ToLower() == nomeGenero.ToLower());

            if (generoExistente != null)
            {
                // 2. Se já existe, apenas associa ao filme
                filme.Generos.Add(generoExistente);
            }
            else
            {
                // 3. Se não existe, cria um novo objeto Genero e associa
                filme.Generos.Add(new Genero { Nome = nomeGenero });
            }
        }

        _context.Filmes.Add(filme);
        await _context.SaveChangesAsync();

        return ToResponseDto(filme);
    }

public async Task<FilmeResponseDto?> UpdateAsync(int id, FilmeUpdateDto dto)
{
    // 1. Busca o filme com os gêneros atuais para iniciar a alteração
    var filme = await _context.Filmes
        .Include(f => f.Generos)
        .FirstOrDefaultAsync(f => f.Id == id);

    if (filme is null) return null;

    // 2. Atualiza os dados básicos
    filme.Titulo = dto.Titulo;
    filme.Diretor = dto.Diretor;
    filme.Ano = dto.Ano;
    filme.QuantidadeDisponivel = dto.QuantidadeDisponivel;

    // 3. Mapeia os novos gêneros sem quebrar a lista original
    var generosParaAdicionar = new List<Genero>();
    foreach (var nomeGenero in dto.Generos)
    {
        if (filme.Generos.Any(g => g.Nome.ToLower() == nomeGenero.ToLower()))
            continue;

        var generoBanco = await _context.Generos
            .FirstOrDefaultAsync(g => g.Nome.ToLower() == nomeGenero.ToLower());

        if (generoBanco != null)
            generosParaAdicionar.Add(generoBanco);
        else
            generosParaAdicionar.Add(new Genero { Nome = nomeGenero });
    }

    // 4. Remove o que não veio no DTO
    var generosParaRemover = filme.Generos
        .Where(g => !dto.Generos.Select(n => n.ToLower()).Contains(g.Nome.ToLower()))
        .ToList();

    foreach (var genero in generosParaRemover)
    {
        filme.Generos.Remove(genero);
    }

    // 5. Adiciona os novos
    foreach (var genero in generosParaAdicionar)
    {
        filme.Generos.Add(genero);
    }

    // 6. Salva as alterações de fato no banco de dados
    await _context.SaveChangesAsync();

    // ================= MÁGICA DA CORREÇÃO =================
    // 7. Buscamos o filme novamente do banco, zerado e atualizado, 
    // garantindo que os novos gêneros e a data original sejam lidos corretamente.
    var filmeAtualizadoDoBanco = await _context.Filmes
        .Include(f => f.Generos)
        .FirstOrDefaultAsync(f => f.Id == id);

    return ToResponseDto(filmeAtualizadoDoBanco!);
}




    public async Task<bool> DeleteAsync(int id)
    {
        var filme = await _context.Filmes.FindAsync(id);
        if (filme is null) return false;

        _context.Filmes.Remove(filme);
        await _context.SaveChangesAsync();

        return true;
    }

    public async Task<IEnumerable<FilmeResponseDto>> SearchByNameAsync(string nome)
    {
        return await _context.Filmes
            .Where(p => p.Titulo.Contains(nome))
            .Select(p => ToResponseDto(p))
            .ToListAsync();
    }

    // Método privado pra converter Model → ResponseDto
    private static FilmeResponseDto ToResponseDto(Filme p) => 
    new FilmeResponseDto(
        p.Id,
        p.Titulo,
        p.Diretor,
        p.Ano,
        p.Generos.Select(g => new GeneroDTO(g.Id, g.Nome)),
        p.QuantidadeDisponivel,
        p.AdicionadoEm
    );
}