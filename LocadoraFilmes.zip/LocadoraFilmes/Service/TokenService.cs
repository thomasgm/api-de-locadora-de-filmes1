using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using LocadoraFilmes.Models;

namespace LocadoraFilmes.Services;

// Esta classe é responsável por gerar o Token JWT para o usuário logado
public class TokenService
{
    private readonly IConfiguration _config;

    public TokenService(IConfiguration config)
    {
        _config = config;
    }

    public string GenerateToken(Cliente cliente)
    {
        var keyString = _config["Jwt:Key"] ?? "chavedefaultparagerarotenteste"; // Use uma chave forte e secreta em produção!
        var key = Encoding.ASCII.GetBytes(keyString);
        
        // Define o que vai dentro do token (Payload/Claims)
        var tokenDescriptor = new SecurityTokenDescriptor
        {
            Subject = new ClaimsIdentity(new[]
            {
                new Claim(ClaimTypes.Name, cliente.Nome),
                new Claim(ClaimTypes.Email, cliente.Email),
                new Claim(ClaimTypes.NameIdentifier, cliente.Id.ToString())
            }),
            Expires = DateTime.UtcNow.AddHours(2), // O token expira em 2 horas
            // Assinatura digital do token
            SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
        };

        var tokenHandler = new JwtSecurityTokenHandler();
        var token = tokenHandler.CreateToken(tokenDescriptor);
        
        // Retorna o token como uma string
        return tokenHandler.WriteToken(token);
    }
}
