using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LocadoraFilmes.Data;
using LocadoraFilmes.DTOs;
using LocadoraFilmes.Models;
using LocadoraFilmes.Services;

namespace LocadoraFilmes.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly TokenService _tokenService;

    public AuthController(AppDbContext context, TokenService tokenService)
    {
        _context = context;
        _tokenService = tokenService;
    }

    // POST: api/auth/register
    [HttpPost("register")]
    public async Task<IActionResult> Register(RegisterRequest request)
    {
        // Verifica se o e-mail já existe
        if (await _context.Clientes.AnyAsync(c => c.Email == request.Email))
            return BadRequest(new { message = "Este e-mail já está em uso." });

        var cliente = new Cliente
        {
            Nome = request.Nome,
            Email = request.Email,
            SenhaHash = request.SenhaHash // IMPORTANTE: Use BCrypt ou similar para hash de senha!
        };

        _context.Clientes.Add(cliente);
        await _context.SaveChangesAsync();

        return Ok(new { message = "Cadastro realizado com sucesso!" });
    }

    // POST: api/auth/login
    [HttpPost("login")]
    public async Task<ActionResult<LoginResponse>> Login(LoginRequest request)
    {
        // Busca o cliente pelo e-mail e senha (em texto simples aqui para fins didáticos)
        var cliente = await _context.Clientes
            .FirstOrDefaultAsync(c => c.Email == request.Email && c.Senha == request.Senha);

        if (cliente == null)
            return Unauthorized(new { message = "Usuário ou senha incorretos." });

        // Gera o Token JWT
        var token = _tokenService.GenerateToken(cliente);

        return Ok(new LoginResponse(token, cliente.Nome));
    }
}
